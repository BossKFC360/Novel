public class Enemy
{
    public string Name;
    public int HP;
    public int Damage;

    public Enemy(string name, int hp, int damage)
    {
        Name = name;
        HP = hp;
        Damage = damage;
    }

    public bool IsAlive()
    {
        return HP > 0;
    }
}