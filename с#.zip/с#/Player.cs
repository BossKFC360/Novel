public class Player
{
    public int HP = 30;

    public int Strength;
    public int Intelligence;
    public int Sanity;

    public bool HasRobot;

    public Player()
    {
        HP = 30;
        Strength = 0;
        Intelligence = 0;
        Sanity = 0;
        HasRobot = false;
    }

    public bool IsAlive()
    {
        return HP > 0;
    }
}