﻿Player player = new Player();
player.Strength = 2;
player.Intelligence = 1;

Enemy enemy = new Enemy("Brainrot Monster", 25, 4);

BattleSystem battle = new BattleSystem(player, enemy);
bool win = battle.StartBattle();